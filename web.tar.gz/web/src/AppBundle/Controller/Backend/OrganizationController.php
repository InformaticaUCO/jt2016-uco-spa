<?php
/*
 * This file is part of the consignang.
 *
 * (c) Sergio Gómez <sergio@uco.es>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace AppBundle\Controller\Backend;


use AppBundle\Model\OrganizationInterface;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Routing\ClassResourceInterface;
use Hateoas\Configuration\Route;
use Hateoas\Representation\Factory\PagerfantaFactory;
use Symfony\Component\HttpFoundation\Request;

/**
 * Class OrganizationRestController
 * @package AppBundle\Controller
 *
 * @View(serializerGroups={"Default"})
 */
class OrganizationController extends FOSRestController implements ClassResourceInterface
{
    public function cgetAction(Request $request)
    {
        $limit = $request->query->getInt('limit', 200);
        $page = $request->query->getInt('page', 1);
        $sorting = $request->query->get('sorting', []);

        $organizationsPager = $this->get('consigna.repository.organization')->findAllPaginated($limit, $page, $sorting);
        $pagerFactory = new PagerfantaFactory();

        return $pagerFactory->createRepresentation(
            $organizationsPager,
            new Route('get_organizations', ['limit' => $limit, 'page' => $page, 'sorting' => $sorting], true)
        );
    }

    /**
     * @View(serializerGroups={"Default", "show"})
     */
    public function getAction(string $slug)
    {
        $organization = $this->getOrganization($slug);

        return $organization;
    }

    /**
     * @param string $slug
     * @return OrganizationInterface
     */
    private function getOrganization(string $slug)
    {
        $organization = $this->get('consigna.repository.organization')->findOneActiveOrganizationBySlug($slug);
        if (!$organization) {
            throw $this->createNotFoundException();
        }

        return $organization;
    }

}