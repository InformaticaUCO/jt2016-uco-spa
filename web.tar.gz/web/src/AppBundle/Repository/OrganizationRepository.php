<?php
/*
 * This file is part of the consignang.
 *
 * (c) Sergio Gómez <sergio@uco.es>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace AppBundle\Repository;

class OrganizationRepository extends EntityRepository implements OrganizationRepositoryInterface
{
    public function findOneActiveOrganizationBySlug($slug)
    {
        $qb = $this->getAllActiveOrganizationsQuery()
            ->andWhere('o.slug = :slug')
            ->setParameter('slug', $slug)
        ;

        return $qb->getQuery()->getOneOrNullResult();
    }

    public function findAllPaginated(int $limit, int $page, array $sorting = [])
    {
        $queryBuilder = $this->getAllActiveOrganizationsQuery();

        return $this->createPager($queryBuilder, $limit, $page, $sorting);
    }

    public function getAllActiveOrganizationsQuery()
    {
        $qb = $this->createQueryBuilder('o');
        $query = $qb
            ->where('o.enabled = :true')
            ->setParameter('true', true)
        ;

        return $query;
    }

}
