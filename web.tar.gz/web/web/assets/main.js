$(document).ready(function() {
    // fix menu when passed
    $('.masthead')
        .visibility({
            once: false,
            onBottomPassed: function() {
                $('.fixed.menu').transition('fade in');
            },
            onBottomPassedReverse: function() {
                $('.fixed.menu').transition('fade out');
            }
        })
    ;

    // create sidebar and attach to menu open
    $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
    ;

    $('button[data-action="logout"]').hide();
});


hello.on('auth.login', function (auth) {
    var socialToken = auth.authResponse.access_token;

    authenticate(auth.network, socialToken).then(function (token) {
        console.log(jwt_decode(token));
        decodedToken = jwt_decode(token);

        $('button[data-action="logout"]').show();
        $('button[data-action="login"]').hide();
        $('#username').text("Bienvenido " + decodedToken.username);

        axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
    });
});


hello.on('auth.logout', function (auth) {
    $('button[data-action="logout"]').hide();
    $('button[data-action="login"]').show();
    $('#username').text("Inicie sesión para continuar...");

    delete axios.defaults.headers.common['Authorization'];
    $('#organizations').DataTable().destroy();
    $('#organizations tbody').remove();
}, function(e) {
    alert('Signed out error: ' + e.error.message);
});