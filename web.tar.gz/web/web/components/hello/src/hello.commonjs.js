// CommonJS module for browserify
if (typeof module === 'object' && module.exports) {
	module.exports = hello;
}
